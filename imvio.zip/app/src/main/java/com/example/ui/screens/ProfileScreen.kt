package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.UserEntity
import com.example.ui.components.ViewerBottomNavigation
import com.example.ui.components.ViewerTab
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.LightBg
import com.example.ui.theme.LightCardBorder
import com.example.ui.theme.LightTextMuted
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary

@Composable
fun ProfileScreen(
    user: UserEntity?,
    onNavigateTab: (ViewerTab) -> Unit,
    onSwitchToCreator: () -> Unit,
    onOpenAdminPanel: () -> Unit,
    onLogout: () -> Unit,
    onUpdateProfile: (name: String, email: String) -> Unit,
    onUpdateBkash: (String) -> Unit
) {
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showBkashDialog by remember { mutableStateOf(false) }
    var showReferralDialog by remember { mutableStateOf(false) }
    var showSupportDialog by remember { mutableStateOf(false) }

    var editName by remember(user?.name) { mutableStateOf(user?.name ?: "Imran Khan") }
    var editEmail by remember(user?.email) { mutableStateOf(user?.email ?: "imran@example.com") }
    var editBkash by remember(user?.bKashNumber) { mutableStateOf(user?.bKashNumber ?: "01712345678") }

    Scaffold(
        containerColor = LightBg,
        bottomBar = {
            ViewerBottomNavigation(
                currentTab = ViewerTab.PROFILE,
                onTabSelected = onNavigateTab,
                isDark = false
            )
        },
        modifier = Modifier.testTag("profile_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Header Title
            Text(
                text = "Profile",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = LightTextPrimary
            )

            Spacer(modifier = Modifier.height(20.dp))

            // User Info Header
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(90.dp),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_avatar_profile),
                        contentDescription = "Avatar",
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .border(2.5.dp, BrandBlue, CircleShape)
                    )

                    // Edit Camera Badge
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(BrandBlue)
                            .border(2.dp, Color.White, CircleShape)
                            .clickable { showEditProfileDialog = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Edit photo",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = user?.name ?: "Imran Khan",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = LightTextPrimary
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = user?.email ?: "imran@example.com",
                    fontSize = 13.sp,
                    color = LightTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Menu Items List Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(3.dp, RoundedCornerShape(20.dp), spotColor = Color(0x10000000))
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
                    .border(1.dp, LightCardBorder, RoundedCornerShape(20.dp))
                    .padding(vertical = 6.dp)
            ) {
                Column {
                    ProfileMenuItem(
                        icon = Icons.Default.Edit,
                        title = "Edit Profile",
                        iconTint = BrandBlue,
                        onClick = { showEditProfileDialog = true },
                        testTag = "menu_edit_profile"
                    )
                    ProfileMenuItem(
                        icon = Icons.Default.PhoneAndroid,
                        title = "bKash Number",
                        subtitle = user?.bKashNumber ?: "01712345678",
                        iconTint = Color(0xFFE2136E),
                        onClick = { showBkashDialog = true },
                        testTag = "menu_bkash"
                    )
                    ProfileMenuItem(
                        icon = Icons.Default.People,
                        title = "My Referrals",
                        subtitle = "Invite friends to earn 100 pts",
                        iconTint = BrandPurple,
                        onClick = { showReferralDialog = true },
                        testTag = "menu_referrals"
                    )
                    ProfileMenuItem(
                        icon = Icons.Default.SwapHoriz,
                        title = "Switch to Creator Mode",
                        subtitle = "Manage campaigns & promote",
                        iconTint = BrandCyan,
                        onClick = onSwitchToCreator,
                        testTag = "menu_switch_creator"
                    )
                    ProfileMenuItem(
                        icon = Icons.Default.AdminPanelSettings,
                        title = "Admin Panel",
                        subtitle = "Moderate withdrawals & content",
                        iconTint = Color(0xFFF59E0B),
                        onClick = onOpenAdminPanel,
                        testTag = "menu_admin_panel"
                    )
                    ProfileMenuItem(
                        icon = Icons.AutoMirrored.Filled.HelpOutline,
                        title = "Help & Support",
                        iconTint = BrandGreen,
                        onClick = { showSupportDialog = true },
                        testTag = "menu_help"
                    )
                    ProfileMenuItem(
                        icon = Icons.AutoMirrored.Filled.Logout,
                        title = "Logout",
                        iconTint = Color(0xFFEF4444),
                        textColor = Color(0xFFEF4444),
                        onClick = onLogout,
                        testTag = "menu_logout"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit Profile") },
            text = {
                Column {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Full Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = editEmail,
                        onValueChange = { editEmail = it },
                        label = { Text("Email Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onUpdateProfile(editName, editEmail)
                        showEditProfileDialog = false
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // bKash Edit Dialog
    if (showBkashDialog) {
        AlertDialog(
            onDismissRequest = { showBkashDialog = false },
            title = { Text("Update bKash Number") },
            text = {
                Column {
                    Text("Enter your 11-digit personal bKash number:")
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editBkash,
                        onValueChange = { editBkash = it },
                        placeholder = { Text("01XXXXXXXXX") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onUpdateBkash(editBkash)
                        showBkashDialog = false
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBkashDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Referral Dialog
    if (showReferralDialog) {
        AlertDialog(
            onDismissRequest = { showReferralDialog = false },
            title = { Text("Refer & Earn") },
            text = {
                Column {
                    Text("Share your code with friends. When they join, both of you get 100 bonus points!")
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFEFF6FF))
                            .border(1.dp, Color(0xFF93C5FD), RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user?.referralCode ?: "IMVIO-9821",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            color = BrandBlue,
                            letterSpacing = 2.sp
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReferralDialog = false }) {
                    Text("Done")
                }
            }
        )
    }

    // Help & Support Dialog
    if (showSupportDialog) {
        AlertDialog(
            onDismissRequest = { showSupportDialog = false },
            title = { Text("Help & Support") },
            text = {
                Column {
                    Text("Need help with earnings or campaign management?")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Email: support@imvio.app", fontWeight = FontWeight.SemiBold)
                    Text("• Telegram: @iMVIOOfficial", fontWeight = FontWeight.SemiBold)
                    Text("• Payout helpline: 10:00 AM - 8:00 PM (GMT+6)")
                }
            },
            confirmButton = {
                TextButton(onClick = { showSupportDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
fun ProfileMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    iconTint: Color,
    textColor: Color = LightTextPrimary,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp)
            .testTag(testTag),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconTint.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = textColor
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        fontSize = 12.sp,
                        color = LightTextMuted
                    )
                }
            }
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = LightTextMuted,
            modifier = Modifier.size(14.dp)
        )
    }
}
