package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GradientButton
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.DarkBg
import com.example.ui.theme.LightCardBorder
import com.example.ui.theme.LightTextMuted
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateCampaignScreen(
    onBackClick: () -> Unit,
    onCampaignCreated: (title: String, platform: String, url: String, views: Int, budget: Double) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedPlatform by remember { mutableStateOf("YouTube") }
    var platformExpanded by remember { mutableStateOf(false) }
    val platforms = listOf("YouTube", "Facebook", "TikTok", "Instagram", "In-App Video")

    var videoUrl by remember { mutableStateOf("") }
    var viewsNeededInput by remember { mutableStateOf("5000") }
    var budgetInput by remember { mutableStateOf("500") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val viewsInt = viewsNeededInput.toIntOrNull() ?: 0
    val budgetDouble = budgetInput.toDoubleOrNull() ?: 0.0

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("create_campaign_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("campaign_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Create Campaign",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // White Elevated Form Container Card matching reference
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(8.dp, RoundedCornerShape(24.dp), spotColor = Color(0x20000000))
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White)
                    .padding(22.dp)
            ) {
                Column {
                    Text(
                        text = "Campaign Details",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = LightTextPrimary
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Campaign Title
                    Text(
                        text = "Campaign Title",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LightTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it; errorMessage = null },
                        placeholder = { Text("Enter campaign title", color = LightTextMuted) },
                        leadingIcon = {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = BrandBlue)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandBlue,
                            unfocusedBorderColor = LightCardBorder,
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_campaign_title")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Platform Selector Dropdown
                    Text(
                        text = "Platform",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LightTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    ExposedDropdownMenuBox(
                        expanded = platformExpanded,
                        onExpandedChange = { platformExpanded = !platformExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedPlatform,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = platformExpanded) },
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BrandBlue,
                                unfocusedBorderColor = LightCardBorder,
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = platformExpanded,
                            onDismissRequest = { platformExpanded = false }
                        ) {
                            platforms.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text(p) },
                                    onClick = {
                                        selectedPlatform = p
                                        platformExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Video Link
                    Text(
                        text = "Video Link",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LightTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = videoUrl,
                        onValueChange = { videoUrl = it; errorMessage = null },
                        placeholder = { Text("https://youtu.be/...", color = LightTextMuted) },
                        leadingIcon = {
                            Icon(Icons.Default.Link, contentDescription = null, tint = BrandBlue)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandBlue,
                            unfocusedBorderColor = LightCardBorder,
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_campaign_url")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Views Needed
                    Text(
                        text = "Total Views Needed",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LightTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = viewsNeededInput,
                        onValueChange = { viewsNeededInput = it; errorMessage = null },
                        placeholder = { Text("5000", color = LightTextMuted) },
                        leadingIcon = {
                            Icon(Icons.Default.Visibility, contentDescription = null, tint = BrandBlue)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandBlue,
                            unfocusedBorderColor = LightCardBorder,
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_campaign_views")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Budget (BDT)
                    Text(
                        text = "Budget (BDT)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LightTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = budgetInput,
                        onValueChange = { budgetInput = it; errorMessage = null },
                        placeholder = { Text("500", color = LightTextMuted) },
                        leadingIcon = {
                            Icon(Icons.Default.Payments, contentDescription = null, tint = BrandBlue)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandBlue,
                            unfocusedBorderColor = LightCardBorder,
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_campaign_budget")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Cost estimation banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF0FDF4))
                            .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = BrandGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Estimated: ৳0.10 / view • ৳%.0f total".format(budgetDouble),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D)
                            )
                        }
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMessage!!,
                            color = Color(0xFFEF4444),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Create Campaign Button
                    GradientButton(
                        text = "Create Campaign",
                        onClick = {
                            if (title.isBlank()) {
                                errorMessage = "Please enter a campaign title"
                            } else if (videoUrl.isBlank()) {
                                errorMessage = "Please enter a video URL"
                            } else if (viewsInt < 100) {
                                errorMessage = "Minimum 100 views required"
                            } else if (budgetDouble < 50) {
                                errorMessage = "Minimum budget is ৳50"
                            } else {
                                onCampaignCreated(title, selectedPlatform, videoUrl, viewsInt, budgetDouble)
                            }
                        },
                        testTag = "submit_create_campaign_btn"
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
