package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.UserEntity
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandMagenta
import com.example.ui.theme.DarkBg
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    currentUser: UserEntity?,
    onNavigateNext: (destinationRoute: String) -> Unit
) {
    val scale = remember { Animatable(0.85f) }
    val alpha = remember { Animatable(0f) }
    val waveOffset = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        waveOffset.animateTo(
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(4000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            )
        )
    }

    LaunchedEffect(Unit) {
        scale.animateTo(1f, animationSpec = tween(700, easing = FastOutSlowInEasing))
        alpha.animateTo(1f, animationSpec = tween(500))
        delay(1800)
        val nextRoute = when (currentUser?.role) {
            "CREATOR" -> "creator_dashboard"
            "VIEWER" -> "viewer_home"
            else -> "welcome"
        }
        onNavigateNext(nextRoute)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .clickable {
                val nextRoute = when (currentUser?.role) {
                    "CREATOR" -> "creator_dashboard"
                    "VIEWER" -> "viewer_home"
                    else -> "welcome"
                }
                onNavigateNext(nextRoute)
            }
            .testTag("splash_screen")
    ) {
        // Subtle ambient radial glow behind logo
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF3B82F6).copy(alpha = 0.15f), Color.Transparent),
                    center = center,
                    radius = size.minDimension * 0.7f
                )
            )
        }

        // Center Content: Logo + Brand + Tagline
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 24.dp)
                .scale(scale.value)
                .alpha(alpha.value),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_imvio_logo),
                contentDescription = "iMVIO Logo",
                modifier = Modifier
                    .size(120.dp)
                    .clip(RoundedCornerShape(28.dp))
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "i",
                    color = BrandCyan,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-1).sp
                )
                Text(
                    text = "MVIO",
                    color = Color.White,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-1).sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Create. Watch. Earn.",
                color = BrandCyan,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.2.sp
            )
        }

        // Flowing Wave Decoration near bottom
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .align(Alignment.BottomCenter)
        ) {
            val width = size.width
            val height = size.height

            // Wave 1: Blue to Purple
            val path1 = Path().apply {
                moveTo(0f, height * 0.6f)
                cubicTo(
                    width * 0.25f, height * 0.2f,
                    width * 0.65f, height * 0.9f,
                    width, height * 0.4f
                )
            }
            drawPath(
                path = path1,
                brush = Brush.horizontalGradient(
                    listOf(Color(0xFF06B6D4), Color(0xFF3B82F6), Color(0xFF8B5CF6))
                ),
                style = Stroke(width = 3.5f)
            )

            // Wave 2: Magenta to Purple
            val path2 = Path().apply {
                moveTo(0f, height * 0.75f)
                cubicTo(
                    width * 0.35f, height * 0.95f,
                    width * 0.75f, height * 0.35f,
                    width, height * 0.65f
                )
            }
            drawPath(
                path = path2,
                brush = Brush.horizontalGradient(
                    listOf(BrandMagenta, Color(0xFF7C3AED), Color(0xFF3B82F6))
                ),
                style = Stroke(width = 2.5f)
            )
        }

        // Bottom Slogan: "A Better View. A Brighter You."
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "A Better View",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "A Brighter You",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal
            )
        }
    }
}
