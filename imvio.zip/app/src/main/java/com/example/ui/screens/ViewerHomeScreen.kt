package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.UserEntity
import com.example.ui.components.BalanceGradientCard
import com.example.ui.components.IMVIOHeaderLogo
import com.example.ui.components.ViewerBottomNavigation
import com.example.ui.components.ViewerTab
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueLight
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandMagenta
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.BrandYellow
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary

data class VideoItem(
    val id: String,
    val title: String,
    val duration: String,
    val points: Int,
    val imageRes: Int
)

@Composable
fun ViewerHomeScreen(
    user: UserEntity?,
    unreadNotifCount: Int,
    onNavigateTab: (ViewerTab) -> Unit,
    onOpenVideo: (String) -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenReferDialog: () -> Unit,
    onClaimDailyBonus: () -> Unit
) {
    val sampleVideos = listOf(
        VideoItem("1", "Travel Bangladesh", "2 min", 50, R.drawable.img_video_watch_bg),
        VideoItem("2", "Healthy Life Tips", "3 min", 50, R.drawable.img_welcome_hero),
        VideoItem("3", "Dhaka Street Food", "1 min", 30, R.drawable.img_imvio_logo)
    )

    Scaffold(
        containerColor = DarkBg,
        bottomBar = {
            ViewerBottomNavigation(
                currentTab = ViewerTab.HOME,
                onTabSelected = onNavigateTab,
                isDark = true
            )
        },
        modifier = Modifier.testTag("viewer_home_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Top Header: Logo + Notifications + Avatar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IMVIOHeaderLogo(isDark = true)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onOpenNotifications,
                        modifier = Modifier.testTag("home_notif_btn")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifCount > 0) {
                                    Badge(containerColor = Color(0xFFEF4444)) {
                                        Text("$unreadNotifCount", color = Color.White)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notifications",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Image(
                        painter = painterResource(id = R.drawable.img_avatar_profile),
                        contentDescription = "User Avatar",
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, BrandCyan, CircleShape)
                            .clickable { onNavigateTab(ViewerTab.PROFILE) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Greeting: "Hello, Imran / Keep watching, keep earning!"
            Column {
                Text(
                    text = "Hello, ${user?.name?.substringBefore(" ") ?: "Imran"}",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Keep watching, keep earning!",
                    color = DarkTextSecondary,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Points Card
            val pts = user?.pointsBalance ?: 2450
            BalanceGradientCard(
                points = pts,
                bdtValue = pts * 0.1,
                onWalletClick = { onNavigateTab(ViewerTab.WALLET) }
            )

            Spacer(modifier = Modifier.height(22.dp))

            // 4 Colorful Shortcuts: Watch, Tasks, Bonus, Refer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ShortcutButton(
                    label = "Watch",
                    icon = Icons.Default.PlayCircle,
                    gradient = Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF38BDF8))),
                    onClick = { onOpenVideo("1") },
                    testTag = "shortcut_watch"
                )
                ShortcutButton(
                    label = "Tasks",
                    icon = Icons.Default.TaskAlt,
                    gradient = Brush.linearGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))),
                    onClick = { onNavigateTab(ViewerTab.EARN) },
                    testTag = "shortcut_tasks"
                )
                ShortcutButton(
                    label = "Bonus",
                    icon = Icons.Default.CardGiftcard,
                    gradient = Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFFBBF24))),
                    onClick = onClaimDailyBonus,
                    testTag = "shortcut_bonus"
                )
                ShortcutButton(
                    label = "Refer",
                    icon = Icons.Default.People,
                    gradient = Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF34D399))),
                    onClick = onOpenReferDialog,
                    testTag = "shortcut_refer"
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // "Today's Videos" Header + "See All"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Today's Videos",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "See All",
                    color = BrandBlueLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onNavigateTab(ViewerTab.EARN) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Horizontal List of Video Thumbnail Cards
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(sampleVideos) { video ->
                    VideoCardItem(
                        video = video,
                        onClick = { onOpenVideo(video.id) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ShortcutButton(
    label: String,
    icon: ImageVector,
    gradient: Brush,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(gradient),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun VideoCardItem(
    video: VideoItem,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(170.dp)
            .height(210.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(DarkCardBg)
            .border(1.dp, DarkCardBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag("video_card_${video.id}")
    ) {
        // Thumbnail Image
        Image(
            painter = painterResource(id = video.imageRes),
            contentDescription = video.title,
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)),
            contentScale = ContentScale.Crop
        )

        // Play Button Overlay on thumbnail
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 45.dp)
                .size(38.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f))
                .border(1.dp, Color.White.copy(alpha = 0.8f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Play",
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
        }

        // Details at bottom
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Text(
                text = video.title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(3.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${video.duration} • ${video.points} Pts",
                    color = BrandCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
