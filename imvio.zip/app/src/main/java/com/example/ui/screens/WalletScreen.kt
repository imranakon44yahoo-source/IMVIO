package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserEntity
import com.example.ui.components.GradientButton
import com.example.ui.components.ViewerBottomNavigation
import com.example.ui.components.ViewerTab
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.BrandYellow
import com.example.ui.theme.CardGradient
import com.example.ui.theme.LightBg
import com.example.ui.theme.LightCardBorder
import com.example.ui.theme.LightTextMuted
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary

@Composable
fun WalletScreen(
    user: UserEntity?,
    onWithdrawClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onSaveBkash: (String) -> Unit,
    onNavigateTab: (ViewerTab) -> Unit,
    onBackClick: (() -> Unit)? = null
) {
    var bkashInput by remember(user?.bKashNumber) {
        mutableStateOf(user?.bKashNumber ?: "01712345678")
    }
    var showConvertDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = LightBg,
        bottomBar = {
            ViewerBottomNavigation(
                currentTab = ViewerTab.WALLET,
                onTabSelected = onNavigateTab,
                isDark = false
            )
        },
        modifier = Modifier.testTag("wallet_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onBackClick != null) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("wallet_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }
                Text(
                    text = "Wallet",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = LightTextPrimary
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Balance Card
            val pts = user?.pointsBalance ?: 2450
            val bdt = pts * 0.1

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(10.dp, RoundedCornerShape(24.dp), spotColor = BrandBlue.copy(alpha = 0.3f))
                    .clip(RoundedCornerShape(24.dp))
                    .background(CardGradient)
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Total Points",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "%,d".format(pts),
                            color = Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "≈ ৳%.2f".format(bdt),
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // 3D Gold Coin
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(BrandYellow.copy(alpha = 0.35f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "Points Coin",
                            tint = Color(0xFFFFE066),
                            modifier = Modifier.size(46.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 3 Circular Action Buttons: Withdraw, History, Convert
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                WalletActionPill(
                    icon = Icons.Default.Payments,
                    label = "Withdraw",
                    color = BrandGreen,
                    onClick = onWithdrawClick,
                    testTag = "wallet_btn_withdraw"
                )
                WalletActionPill(
                    icon = Icons.Default.History,
                    label = "History",
                    color = BrandPurple,
                    onClick = onHistoryClick,
                    testTag = "wallet_btn_history"
                )
                WalletActionPill(
                    icon = Icons.Default.CurrencyExchange,
                    label = "Convert",
                    color = BrandCyan,
                    onClick = { showConvertDialog = true },
                    testTag = "wallet_btn_convert"
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // "Withdraw to bKash" Section Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(3.dp, RoundedCornerShape(20.dp), spotColor = Color(0x10000000))
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
                    .border(1.dp, LightCardBorder, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Withdraw to bKash",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = LightTextPrimary
                        )

                        Text(
                            text = "bKash",
                            color = Color(0xFFE2136E),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = bkashInput,
                            onValueChange = { bkashInput = it },
                            placeholder = { Text("01XXXXXXXXX", color = LightTextMuted) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BrandBlue,
                                unfocusedBorderColor = LightCardBorder,
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("wallet_bkash_input")
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(BrandBlue)
                                .clickable { onSaveBkash(bkashInput) }
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                                .testTag("wallet_save_bkash_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Save",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Minimum withdrawal: 1,000 Points (৳100)",
                        fontSize = 12.sp,
                        color = LightTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Request Withdrawal Button
            GradientButton(
                text = "Request Withdrawal",
                onClick = onWithdrawClick,
                testTag = "wallet_request_withdrawal_btn"
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showConvertDialog) {
        AlertDialog(
            onDismissRequest = { showConvertDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CurrencyExchange, contentDescription = null, tint = BrandBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Points Conversion")
                }
            },
            text = {
                Column {
                    Text("Current Exchange Rate:", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("100 Points = ৳10.00 BDT", color = BrandGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Your current points: %,d Points".format(user?.pointsBalance ?: 2450))
                    Text("Equivalent cash value: ৳%.2f BDT".format((user?.pointsBalance ?: 2450) * 0.1))
                }
            },
            confirmButton = {
                TextButton(onClick = { showConvertDialog = false }) {
                    Text("Got It")
                }
            }
        )
    }
}

@Composable
fun WalletActionPill(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.12f))
                .border(1.5.dp, color.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = LightTextPrimary
        )
    }
}
