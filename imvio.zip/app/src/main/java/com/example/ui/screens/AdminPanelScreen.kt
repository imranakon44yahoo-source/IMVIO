package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CampaignEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserEntity
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary

@Composable
fun AdminPanelScreen(
    users: List<UserEntity>,
    campaigns: List<CampaignEntity>,
    pendingWithdrawals: List<TransactionEntity>,
    onBackClick: () -> Unit,
    onApproveWithdrawal: (TransactionEntity, String) -> Unit,
    onRejectWithdrawal: (TransactionEntity) -> Unit,
    onToggleCampaign: (Long, String) -> Unit
) {
    var selectedSection by remember { mutableStateOf("Dashboard") }
    val sections = listOf("Dashboard", "Withdrawals", "Campaigns", "Users", "Settings")

    var approveTxTarget by remember { mutableStateOf<TransactionEntity?>(null) }
    var payoutTrxIdInput by remember { mutableStateOf("9X87KL1P") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .statusBarsPadding()
            .testTag("admin_panel_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("admin_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Admin Panel",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sub-tabs list matching reference
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(sections) { section ->
                    val isSelected = section == selectedSection
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) BrandBlue else DarkCardBg)
                            .border(1.dp, if (isSelected) BrandBlue else DarkCardBorder, RoundedCornerShape(16.dp))
                            .clickable { selectedSection = section }
                            .padding(horizontal = 16.dp, vertical = 7.dp)
                            .testTag("admin_tab_$section")
                    ) {
                        Text(
                            text = section,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Content per sub-tab
            when (selectedSection) {
                "Dashboard" -> {
                    AdminDashboardOverview(
                        userCount = users.size,
                        campaignCount = campaigns.size,
                        pendingCount = pendingWithdrawals.size
                    )
                }
                "Withdrawals" -> {
                    AdminWithdrawalsTab(
                        pendingWithdrawals = pendingWithdrawals,
                        onApprove = { tx -> approveTxTarget = tx },
                        onReject = onRejectWithdrawal
                    )
                }
                "Campaigns" -> {
                    AdminCampaignsTab(
                        campaigns = campaigns,
                        onToggle = onToggleCampaign
                    )
                }
                "Users" -> {
                    AdminUsersTab(users = users)
                }
                "Settings" -> {
                    AdminSettingsTab()
                }
            }
        }
    }

    if (approveTxTarget != null) {
        AlertDialog(
            onDismissRequest = { approveTxTarget = null },
            title = { Text("Approve Withdrawal") },
            text = {
                Column {
                    Text("Approving payout of ৳${(kotlin.math.abs(approveTxTarget!!.points) * 0.1).toInt()} to bKash.")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = payoutTrxIdInput,
                        onValueChange = { payoutTrxIdInput = it },
                        label = { Text("bKash TrxID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onApproveWithdrawal(approveTxTarget!!, payoutTrxIdInput)
                        approveTxTarget = null
                    }
                ) {
                    Text("Approve & Pay")
                }
            },
            dismissButton = {
                TextButton(onClick = { approveTxTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AdminDashboardOverview(
    userCount: Int,
    campaignCount: Int,
    pendingCount: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "Platform Overview",
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DashboardStatCard(
                modifier = Modifier.weight(1f),
                title = "Total Users",
                value = "$userCount",
                icon = Icons.Default.Group,
                accentColor = BrandBlue
            )
            DashboardStatCard(
                modifier = Modifier.weight(1f),
                title = "Pending Payouts",
                value = "$pendingCount",
                icon = Icons.Default.Payments,
                accentColor = BrandOrange
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DashboardStatCard(
                modifier = Modifier.weight(1f),
                title = "Campaigns",
                value = "$campaignCount",
                icon = Icons.Default.Campaign,
                accentColor = BrandCyan
            )
            DashboardStatCard(
                modifier = Modifier.weight(1f),
                title = "Payout Success",
                value = "99.4%",
                icon = Icons.Default.ReceiptLong,
                accentColor = BrandGreen
            )
        }
    }
}

@Composable
fun AdminWithdrawalsTab(
    pendingWithdrawals: List<TransactionEntity>,
    onApprove: (TransactionEntity) -> Unit,
    onReject: (TransactionEntity) -> Unit
) {
    Column {
        Text(
            text = "Pending bKash Withdrawals (${pendingWithdrawals.size})",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (pendingWithdrawals.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 40.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No pending withdrawal requests.", color = DarkTextSecondary)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(pendingWithdrawals) { tx ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(DarkCardBg)
                            .border(1.dp, DarkCardBorder, RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Ref: ${tx.referenceId.ifBlank { "#${tx.id}" }}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = tx.dateDisplay,
                                        color = DarkTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                                Text(
                                    text = "৳%.0f (${kotlin.math.abs(tx.points)} Pts)".format(kotlin.math.abs(tx.points) * 0.1),
                                    color = BrandCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFEF4444).copy(alpha = 0.2f))
                                        .clickable { onReject(tx) }
                                        .padding(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Text("Reject", color = Color(0xFFEF4444), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(BrandGreen)
                                        .clickable { onApprove(tx) }
                                        .padding(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Text("Approve & Pay", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminCampaignsTab(
    campaigns: List<CampaignEntity>,
    onToggle: (Long, String) -> Unit
) {
    Column {
        Text(
            text = "Active & Reviewed Campaigns",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(campaigns) { camp ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(DarkCardBg)
                        .border(1.dp, DarkCardBorder, RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = camp.title,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${camp.platform} • Budget ৳${camp.budgetBdt.toInt()} • ${camp.viewsCurrent}/${camp.viewsNeeded} views",
                                color = DarkTextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (camp.status == "ACTIVE") BrandGreen else Color(0xFFF59E0B))
                                .clickable { onToggle(camp.id, camp.status) }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = if (camp.status == "ACTIVE") "Active" else "Paused",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminUsersTab(users: List<UserEntity>) {
    Column {
        Text(
            text = "Registered Members (${users.size})",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(users) { u ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkCardBg)
                        .border(1.dp, DarkCardBorder, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(u.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${u.email} • ${u.role}", color = DarkTextSecondary, fontSize = 12.sp)
                        }
                        Text("${u.pointsBalance} Pts", color = BrandCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminSettingsTab() {
    Column(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "Platform Settings",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(DarkCardBg)
                .border(1.dp, DarkCardBorder, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Points Conversion Rate: 100 Points = ৳10.00 BDT", color = Color.White, fontSize = 13.sp)
                Text("Minimum Withdrawal: 1,000 Points", color = Color.White, fontSize = 13.sp)
                Text("Payout Gateway: bKash Personal Merchant API (Live)", color = BrandGreen, fontSize = 13.sp)
                Text("Escrow Protection: Enabled", color = BrandCyan, fontSize = 13.sp)
            }
        }
    }
}
