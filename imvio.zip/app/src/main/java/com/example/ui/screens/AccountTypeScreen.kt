package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.IMVIOHeaderLogo
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LightBg
import com.example.ui.theme.LightCardBorder
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary

@Composable
fun AccountTypeScreen(
    onSelectViewer: () -> Unit,
    onSelectCreator: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LightBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("account_type_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))
            IMVIOHeaderLogo(isDark = false)
            Spacer(modifier = Modifier.height(36.dp))

            Text(
                text = "Choose Your Account Type",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = LightTextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Select how you want to use iMVIO",
                fontSize = 14.sp,
                color = LightTextSecondary
            )

            Spacer(modifier = Modifier.height(36.dp))

            // Card 1: Viewer
            AccountTypeCard(
                title = "I'm a Viewer",
                description = "Watch videos, complete tasks and earn rewards",
                icon = Icons.Default.PlayCircle,
                accentColor = BrandBlue,
                gradient = Brush.linearGradient(
                    listOf(Color(0xFFEFF6FF), Color(0xFFE0E7FF))
                ),
                onClick = onSelectViewer,
                testTag = "select_viewer_card"
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Card 2: Creator
            AccountTypeCard(
                title = "I'm a Creator",
                description = "Promote your content and grow your reach",
                icon = Icons.Default.Videocam,
                accentColor = Color(0xFF7C3AED),
                gradient = Brush.linearGradient(
                    listOf(Color(0xFFFAF5FF), Color(0xFFF3E8FF))
                ),
                onClick = onSelectCreator,
                testTag = "select_creator_card"
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun AccountTypeCard(
    title: String,
    description: String,
    icon: ImageVector,
    accentColor: Color,
    gradient: Brush,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, shape = RoundedCornerShape(22.dp), spotColor = Color(0x15000000))
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .border(1.5.dp, LightCardBorder, RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            // Illustrated Hero Banner Header for Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(gradient),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.9f))
                        .shadow(4.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = LightTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = description,
                        fontSize = 13.sp,
                        color = LightTextSecondary,
                        lineHeight = 18.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(accentColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Select",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
