package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueLight
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandMagenta
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.BrandYellow
import com.example.ui.theme.CardGradient
import com.example.ui.theme.DarkCardBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.LightCardBorder
import com.example.ui.theme.LightTextMuted
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.PrimaryGradient

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    testTag: String = "gradient_button"
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .shadow(
                elevation = if (enabled) 8.dp else 0.dp,
                shape = RoundedCornerShape(26.dp),
                spotColor = BrandPurple.copy(alpha = 0.5f)
            )
            .clip(RoundedCornerShape(26.dp))
            .background(
                if (enabled) PrimaryGradient else Brush.horizontalGradient(
                    listOf(Color(0xFF94A3B8), Color(0xFFCBD5E1))
                )
            )
            .clickable(
                enabled = enabled,
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.3.sp
        )
    }
}

@Composable
fun IMVIOHeaderLogo(
    isDark: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_imvio_logo),
            contentDescription = "iMVIO Logo",
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "i",
                    color = BrandCyan,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "MVIO",
                    color = if (isDark) Color.White else Color(0xFF1E293B),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Text(
                text = "Create. Watch. Earn.",
                color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun BalanceGradientCard(
    points: Int,
    bdtValue: Double,
    onWalletClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .shadow(12.dp, shape = RoundedCornerShape(22.dp), spotColor = BrandBlue.copy(alpha = 0.4f))
            .clip(RoundedCornerShape(22.dp))
            .background(CardGradient)
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(BrandYellow)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "%,d Points".format(points),
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "≈ ৳%.2f".format(bdtValue),
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (onWalletClick != null) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .clickable(onClick = onWalletClick)
                        .padding(horizontal = 18.dp, vertical = 8.dp)
                        .testTag("balance_wallet_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Wallet",
                        color = BrandBlue,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                // Golden coin icon
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFD700).copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = "Coin",
                        tint = Color(0xFFFFE066),
                        modifier = Modifier.size(34.dp)
                    )
                }
            }
        }
    }
}

enum class ViewerTab { HOME, EARN, WALLET, PROFILE }
enum class CreatorTab { DASHBOARD, CAMPAIGNS, ANALYTICS, PROFILE }

@Composable
fun ViewerBottomNavigation(
    currentTab: ViewerTab,
    onTabSelected: (ViewerTab) -> Unit,
    isDark: Boolean = true
) {
    Surface(
        color = if (isDark) DarkCardBg else Color.White,
        shadowElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (isDark) DarkCardBorder else LightCardBorder
            )
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                icon = Icons.Default.Home,
                label = "Home",
                selected = currentTab == ViewerTab.HOME,
                isDark = isDark,
                onClick = { onTabSelected(ViewerTab.HOME) },
                testTag = "nav_home"
            )
            BottomNavItem(
                icon = Icons.Default.MonetizationOn,
                label = "Earn",
                selected = currentTab == ViewerTab.EARN,
                isDark = isDark,
                onClick = { onTabSelected(ViewerTab.EARN) },
                testTag = "nav_earn"
            )
            BottomNavItem(
                icon = Icons.Default.AccountBalanceWallet,
                label = "Wallet",
                selected = currentTab == ViewerTab.WALLET,
                isDark = isDark,
                onClick = { onTabSelected(ViewerTab.WALLET) },
                testTag = "nav_wallet"
            )
            BottomNavItem(
                icon = Icons.Default.Person,
                label = "Profile",
                selected = currentTab == ViewerTab.PROFILE,
                isDark = isDark,
                onClick = { onTabSelected(ViewerTab.PROFILE) },
                testTag = "nav_profile"
            )
        }
    }
}

@Composable
fun CreatorBottomNavigation(
    currentTab: CreatorTab,
    onTabSelected: (CreatorTab) -> Unit,
    isDark: Boolean = true
) {
    Surface(
        color = if (isDark) DarkCardBg else Color.White,
        shadowElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (isDark) DarkCardBorder else LightCardBorder
            )
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                icon = Icons.Default.Dashboard,
                label = "Dashboard",
                selected = currentTab == CreatorTab.DASHBOARD,
                isDark = isDark,
                onClick = { onTabSelected(CreatorTab.DASHBOARD) },
                testTag = "nav_creator_dashboard"
            )
            BottomNavItem(
                icon = Icons.Default.Campaign,
                label = "Campaigns",
                selected = currentTab == CreatorTab.CAMPAIGNS,
                isDark = isDark,
                onClick = { onTabSelected(CreatorTab.CAMPAIGNS) },
                testTag = "nav_creator_campaigns"
            )
            BottomNavItem(
                icon = Icons.Default.ShowChart,
                label = "Analytics",
                selected = currentTab == CreatorTab.ANALYTICS,
                isDark = isDark,
                onClick = { onTabSelected(CreatorTab.ANALYTICS) },
                testTag = "nav_creator_analytics"
            )
            BottomNavItem(
                icon = Icons.Default.Person,
                label = "Profile",
                selected = currentTab == CreatorTab.PROFILE,
                isDark = isDark,
                onClick = { onTabSelected(CreatorTab.PROFILE) },
                testTag = "nav_creator_profile"
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    isDark: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val activeColor = BrandBlueLight
    val inactiveColor = if (isDark) DarkTextSecondary else LightTextMuted

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .testTag(testTag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) activeColor else inactiveColor,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            color = if (selected) activeColor else inactiveColor,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
