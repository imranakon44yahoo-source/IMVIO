package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Brand Gradients & Primary Palette
val BrandBlue = Color(0xFF2563EB)
val BrandBlueLight = Color(0xFF3B82F6)
val BrandPurple = Color(0xFF7C3AED)
val BrandPurpleLight = Color(0xFF8B5CF6)
val BrandCyan = Color(0xFF06B6D4)
val BrandMagenta = Color(0xFFEC4899)
val BrandOrange = Color(0xFFF97316)
val BrandYellow = Color(0xFFF59E0B)
val BrandGreen = Color(0xFF10B981)
val BrandRed = Color(0xFFEF4444)

// Dark Theme Surfaces (Viewer Home, Creator Dashboard, Campaigns bg, Analytics, etc.)
val DarkBg = Color(0xFF090D1A)
val DarkSurface = Color(0xFF12182B)
val DarkCardBg = Color(0xFF161F36)
val DarkCardBorder = Color(0xFF232E4D)
val DarkTextPrimary = Color(0xFFF9FAFB)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Light Theme Surfaces (Welcome, Auth, Wallet, Tasks, Profile, History, etc.)
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCardBg = Color(0xFFFFFFFF)
val LightCardBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF94A3B8)

// Gradients
val PrimaryGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF2563EB), Color(0xFF7C3AED))
)

val CardGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF2563EB), Color(0xFF6366F1), Color(0xFF8B5CF6))
)

val AccentGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
)

val GoldGradient = Brush.linearGradient(
    colors = listOf(Color(0xFFFBBF24), Color(0xFFF59E0B), Color(0xFFD97706))
)
