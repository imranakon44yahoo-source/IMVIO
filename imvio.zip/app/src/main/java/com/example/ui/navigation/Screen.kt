package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Welcome : Screen("welcome")
    object SignUp : Screen("sign_up")
    object Login : Screen("login")
    object AccountType : Screen("account_type")
    object ViewerHome : Screen("viewer_home")
    object VideoWatch : Screen("video_watch")
    object EarnTasks : Screen("earn_tasks")
    object Wallet : Screen("wallet")
    object Withdrawal : Screen("withdrawal")
    object History : Screen("history")
    object Profile : Screen("profile")
    object CreatorDashboard : Screen("creator_dashboard")
    object CreateCampaign : Screen("create_campaign")
    object SubscriptionPlans : Screen("subscription_plans")
    object Analytics : Screen("analytics")
    object Notifications : Screen("notifications")
    object AdminPanel : Screen("admin_panel")
}
