package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.CampaignEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.TaskEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserEntity
import com.example.data.repository.ImvioRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ImvioViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = ImvioRepository(db)

    val currentUser: StateFlow<UserEntity?> = repository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val transactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val campaigns: StateFlow<List<CampaignEntity>> = repository.allCampaigns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasks: StateFlow<List<TaskEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<UserEntity>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingWithdrawals: StateFlow<List<TransactionEntity>> = repository.pendingWithdrawals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Feedback message state
    private val _snackMessage = MutableStateFlow<String?>(null)
    val snackMessage: StateFlow<String?> = _snackMessage.asStateFlow()

    fun clearSnack() {
        _snackMessage.value = null
    }

    fun showMessage(msg: String) {
        _snackMessage.value = msg
    }

    // Role selection
    fun setAccountRole(role: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.updateRole(role)
            onSuccess()
        }
    }

    // Video watch reward
    fun claimWatchReward(points: Int, videoTitle: String, onCompleted: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = repository.awardVideoWatchReward(points, videoTitle)
            if (success) {
                _snackMessage.value = "Awesome! +$points Points added to your wallet!"
            }
            onCompleted(success)
        }
    }

    // Task completion
    fun completeTask(task: TaskEntity) {
        viewModelScope.launch {
            if (task.isCompleted) {
                _snackMessage.value = "This task has already been completed!"
                return@launch
            }
            repository.completeTask(task.id, task.rewardPoints, task.title)
            _snackMessage.value = "Completed! +${task.rewardPoints} Points claimed!"
        }
    }

    // Withdrawal submission
    fun submitWithdrawal(points: Int, bkashNumber: String, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val res = repository.requestWithdrawal(points, bkashNumber)
            res.onSuccess { ref ->
                _snackMessage.value = "Withdrawal request submitted! Ref: $ref"
                onSuccess(ref)
            }.onFailure { err ->
                onError(err.message ?: "Failed to submit request")
            }
        }
    }

    // Update bkash number
    fun saveBkashNumber(number: String) {
        viewModelScope.launch {
            repository.updateBkash(number)
            _snackMessage.value = "bKash number saved successfully!"
        }
    }

    // Create campaign
    fun createCampaign(
        title: String,
        platform: String,
        videoUrl: String,
        viewsNeeded: Int,
        budgetBdt: Double,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.createCampaign(title, platform, videoUrl, viewsNeeded, budgetBdt)
            _snackMessage.value = "Campaign '$title' published successfully!"
            onSuccess()
        }
    }

    // Select Subscription
    fun selectSubscription(plan: String) {
        viewModelScope.launch {
            repository.selectSubscription(plan)
            _snackMessage.value = "Subscribed to $plan Plan successfully!"
        }
    }

    // Update Profile
    fun updateProfile(name: String, email: String) {
        viewModelScope.launch {
            repository.updateProfile(name, email)
            _snackMessage.value = "Profile updated successfully!"
        }
    }

    // Admin actions
    fun adminApproveWithdrawal(tx: TransactionEntity, payoutTrx: String) {
        viewModelScope.launch {
            repository.adminApproveWithdrawal(tx.id, payoutTrx)
            _snackMessage.value = "Withdrawal #${tx.id} approved. Payout TrxID recorded."
        }
    }

    fun adminRejectWithdrawal(tx: TransactionEntity) {
        viewModelScope.launch {
            repository.adminRejectWithdrawal(tx.id, tx.points)
            _snackMessage.value = "Withdrawal #${tx.id} rejected and points refunded."
        }
    }

    fun adminToggleCampaignStatus(campaignId: Long, currentStatus: String) {
        viewModelScope.launch {
            val nextStatus = if (currentStatus == "ACTIVE") "PAUSED" else "ACTIVE"
            repository.adminUpdateCampaignStatus(campaignId, nextStatus)
            _snackMessage.value = "Campaign status changed to $nextStatus"
        }
    }

    fun markNotificationRead(id: Long) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
            _snackMessage.value = "All notifications marked as read"
        }
    }
}
