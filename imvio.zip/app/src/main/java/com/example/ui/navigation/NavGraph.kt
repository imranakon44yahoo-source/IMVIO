package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.CreatorTab
import com.example.ui.components.ViewerTab
import com.example.ui.screens.AccountTypeScreen
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.CreateCampaignScreen
import com.example.ui.screens.CreatorDashboardScreen
import com.example.ui.screens.EarnTasksScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SignUpScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.SubscriptionPlansScreen
import com.example.ui.screens.TransactionHistoryScreen
import com.example.ui.screens.VideoWatchScreen
import com.example.ui.screens.ViewerHomeScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.screens.WithdrawalScreen
import com.example.ui.viewmodel.ImvioViewModel

@Composable
fun ImvioNavGraph(
    viewModel: ImvioViewModel,
    navController: NavHostController = rememberNavController()
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val campaigns by viewModel.campaigns.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val pendingWithdrawals by viewModel.pendingWithdrawals.collectAsState()
    val snackMessage by viewModel.snackMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackMessage) {
        snackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnack()
        }
    }

    val unreadNotifs = notifications.count { !it.isRead }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = Screen.Splash.route
            ) {
                // 1. Splash Screen
                composable(Screen.Splash.route) {
                    SplashScreen(
                        currentUser = currentUser,
                        onNavigateNext = { route ->
                            navController.navigate(route) {
                                popUpTo(Screen.Splash.route) { inclusive = true }
                            }
                        }
                    )
                }

                // 2. Welcome Screen
                composable(Screen.Welcome.route) {
                    WelcomeScreen(
                        onGetStartedClick = { navController.navigate(Screen.SignUp.route) },
                        onSignInClick = { navController.navigate(Screen.Login.route) }
                    )
                }

                // 3. Sign Up Screen
                composable(Screen.SignUp.route) {
                    SignUpScreen(
                        onSignUpSuccess = {
                            navController.navigate(Screen.AccountType.route) {
                                popUpTo(Screen.Welcome.route) { inclusive = true }
                            }
                        },
                        onSignInClick = {
                            navController.navigate(Screen.Login.route) {
                                popUpTo(Screen.SignUp.route) { inclusive = true }
                            }
                        }
                    )
                }

                // 4. Login Screen
                composable(Screen.Login.route) {
                    LoginScreen(
                        onLoginSuccess = {
                            if (currentUser?.role == "CREATOR") {
                                navController.navigate(Screen.CreatorDashboard.route) {
                                    popUpTo(Screen.Welcome.route) { inclusive = true }
                                }
                            } else {
                                navController.navigate(Screen.ViewerHome.route) {
                                    popUpTo(Screen.Welcome.route) { inclusive = true }
                                }
                            }
                        },
                        onSignUpClick = {
                            navController.navigate(Screen.SignUp.route) {
                                popUpTo(Screen.Login.route) { inclusive = true }
                            }
                        }
                    )
                }

                // 5. Account Type Screen
                composable(Screen.AccountType.route) {
                    AccountTypeScreen(
                        onSelectViewer = {
                            viewModel.setAccountRole("VIEWER") {
                                navController.navigate(Screen.ViewerHome.route) {
                                    popUpTo(Screen.AccountType.route) { inclusive = true }
                                }
                            }
                        },
                        onSelectCreator = {
                            viewModel.setAccountRole("CREATOR") {
                                navController.navigate(Screen.CreatorDashboard.route) {
                                    popUpTo(Screen.AccountType.route) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                // 6. Viewer Home Screen
                composable(Screen.ViewerHome.route) {
                    ViewerHomeScreen(
                        user = currentUser,
                        unreadNotifCount = unreadNotifs,
                        onNavigateTab = { tab ->
                            when (tab) {
                                ViewerTab.HOME -> {}
                                ViewerTab.EARN -> navController.navigate(Screen.EarnTasks.route)
                                ViewerTab.WALLET -> navController.navigate(Screen.Wallet.route)
                                ViewerTab.PROFILE -> navController.navigate(Screen.Profile.route)
                            }
                        },
                        onOpenVideo = { navController.navigate(Screen.VideoWatch.route) },
                        onOpenNotifications = { navController.navigate(Screen.Notifications.route) },
                        onOpenReferDialog = {
                            viewModel.showMessage("Your referral code is: ${currentUser?.referralCode ?: "IMVIO-9821"}")
                        },
                        onClaimDailyBonus = {
                            val dailyTask = tasks.firstOrNull { it.category == "BONUS" }
                            if (dailyTask != null) {
                                viewModel.completeTask(dailyTask)
                            } else {
                                viewModel.showMessage("Daily bonus already claimed for today!")
                            }
                        }
                    )
                }

                // 7. Video Watch Screen
                composable(Screen.VideoWatch.route) {
                    VideoWatchScreen(
                        onBackClick = { navController.popBackStack() },
                        onRewardEarned = { points, title ->
                            viewModel.claimWatchReward(points, title) {}
                        }
                    )
                }

                // 8. Earn Tasks Screen
                composable(Screen.EarnTasks.route) {
                    EarnTasksScreen(
                        tasks = tasks,
                        onTaskClick = { task ->
                            if (task.category == "WATCH") {
                                navController.navigate(Screen.VideoWatch.route)
                            } else {
                                viewModel.completeTask(task)
                            }
                        },
                        onNavigateTab = { tab ->
                            when (tab) {
                                ViewerTab.HOME -> navController.navigate(Screen.ViewerHome.route) {
                                    popUpTo(Screen.ViewerHome.route) { inclusive = true }
                                }
                                ViewerTab.EARN -> {}
                                ViewerTab.WALLET -> navController.navigate(Screen.Wallet.route)
                                ViewerTab.PROFILE -> navController.navigate(Screen.Profile.route)
                            }
                        }
                    )
                }

                // 9. Wallet Screen
                composable(Screen.Wallet.route) {
                    WalletScreen(
                        user = currentUser,
                        onWithdrawClick = { navController.navigate(Screen.Withdrawal.route) },
                        onHistoryClick = { navController.navigate(Screen.History.route) },
                        onSaveBkash = { num -> viewModel.saveBkashNumber(num) },
                        onNavigateTab = { tab ->
                            when (tab) {
                                ViewerTab.HOME -> navController.navigate(Screen.ViewerHome.route) {
                                    popUpTo(Screen.ViewerHome.route) { inclusive = true }
                                }
                                ViewerTab.EARN -> navController.navigate(Screen.EarnTasks.route)
                                ViewerTab.WALLET -> {}
                                ViewerTab.PROFILE -> navController.navigate(Screen.Profile.route)
                            }
                        }
                    )
                }

                // 10. Withdrawal Screen
                composable(Screen.Withdrawal.route) {
                    WithdrawalScreen(
                        user = currentUser,
                        onBackClick = { navController.popBackStack() },
                        onSubmitWithdrawal = { points, bkash, onSuccess, onError ->
                            viewModel.submitWithdrawal(points, bkash, onSuccess, onError)
                        },
                        onNavigateToHistory = {
                            navController.navigate(Screen.History.route) {
                                popUpTo(Screen.Withdrawal.route) { inclusive = true }
                            }
                        }
                    )
                }

                // 11. Transaction History Screen
                composable(Screen.History.route) {
                    TransactionHistoryScreen(
                        transactions = transactions,
                        onBackClick = { navController.popBackStack() }
                    )
                }

                // 12. Profile Screen
                composable(Screen.Profile.route) {
                    ProfileScreen(
                        user = currentUser,
                        onNavigateTab = { tab ->
                            when (tab) {
                                ViewerTab.HOME -> navController.navigate(Screen.ViewerHome.route) {
                                    popUpTo(Screen.ViewerHome.route) { inclusive = true }
                                }
                                ViewerTab.EARN -> navController.navigate(Screen.EarnTasks.route)
                                ViewerTab.WALLET -> navController.navigate(Screen.Wallet.route)
                                ViewerTab.PROFILE -> {}
                            }
                        },
                        onSwitchToCreator = {
                            viewModel.setAccountRole("CREATOR") {
                                navController.navigate(Screen.CreatorDashboard.route) {
                                    popUpTo(Screen.ViewerHome.route) { inclusive = true }
                                }
                            }
                        },
                        onOpenAdminPanel = { navController.navigate(Screen.AdminPanel.route) },
                        onLogout = {
                            navController.navigate(Screen.Welcome.route) {
                                popUpTo(0) { inclusive = true }
                            }
                        },
                        onUpdateProfile = { name, email -> viewModel.updateProfile(name, email) },
                        onUpdateBkash = { num -> viewModel.saveBkashNumber(num) }
                    )
                }

                // 13. Creator Dashboard Screen
                composable(Screen.CreatorDashboard.route) {
                    CreatorDashboardScreen(
                        campaigns = campaigns,
                        unreadNotifCount = unreadNotifs,
                        currentSubscription = currentUser?.currentSubscription ?: "Pro",
                        onNavigateTab = { tab ->
                            when (tab) {
                                CreatorTab.DASHBOARD -> {}
                                CreatorTab.CAMPAIGNS -> navController.navigate(Screen.CreateCampaign.route)
                                CreatorTab.ANALYTICS -> navController.navigate(Screen.Analytics.route)
                                CreatorTab.PROFILE -> navController.navigate(Screen.Profile.route)
                            }
                        },
                        onCreateCampaignClick = { navController.navigate(Screen.CreateCampaign.route) },
                        onSubscriptionsClick = { navController.navigate(Screen.SubscriptionPlans.route) },
                        onNotificationsClick = { navController.navigate(Screen.Notifications.route) },
                        onSwitchToViewer = {
                            viewModel.setAccountRole("VIEWER") {
                                navController.navigate(Screen.ViewerHome.route) {
                                    popUpTo(Screen.CreatorDashboard.route) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                // 14. Create Campaign Screen
                composable(Screen.CreateCampaign.route) {
                    CreateCampaignScreen(
                        onBackClick = { navController.popBackStack() },
                        onCampaignCreated = { title, platform, url, views, budget ->
                            viewModel.createCampaign(title, platform, url, views, budget) {
                                navController.popBackStack()
                            }
                        }
                    )
                }

                // 15. Subscription Plans Screen
                composable(Screen.SubscriptionPlans.route) {
                    SubscriptionPlansScreen(
                        currentPlan = currentUser?.currentSubscription ?: "Pro",
                        onBackClick = { navController.popBackStack() },
                        onSelectPlan = { plan ->
                            viewModel.selectSubscription(plan)
                            navController.popBackStack()
                        }
                    )
                }

                // 16. Analytics Screen
                composable(Screen.Analytics.route) {
                    AnalyticsScreen(
                        onBackClick = { navController.popBackStack() }
                    )
                }

                // 17. Notifications Screen
                composable(Screen.Notifications.route) {
                    NotificationsScreen(
                        notifications = notifications,
                        onBackClick = { navController.popBackStack() },
                        onNotificationClick = { notif ->
                            viewModel.markNotificationRead(notif.id)
                            when (notif.targetScreen) {
                                "wallet" -> navController.navigate(Screen.Wallet.route)
                                "history" -> navController.navigate(Screen.History.route)
                                "video_watch" -> navController.navigate(Screen.VideoWatch.route)
                                "creator_dashboard" -> navController.navigate(Screen.CreatorDashboard.route)
                                "subscriptions" -> navController.navigate(Screen.SubscriptionPlans.route)
                                else -> {}
                            }
                        },
                        onMarkAllRead = { viewModel.markAllNotificationsRead() }
                    )
                }

                // 18. Admin Panel Screen
                composable(Screen.AdminPanel.route) {
                    AdminPanelScreen(
                        users = allUsers,
                        campaigns = campaigns,
                        pendingWithdrawals = pendingWithdrawals,
                        onBackClick = { navController.popBackStack() },
                        onApproveWithdrawal = { tx, payoutTrx ->
                            viewModel.adminApproveWithdrawal(tx, payoutTrx)
                        },
                        onRejectWithdrawal = { tx ->
                            viewModel.adminRejectWithdrawal(tx)
                        },
                        onToggleCampaign = { id, status ->
                            viewModel.adminToggleCampaignStatus(id, status)
                        }
                    )
                }
            }
        }
    }
}
