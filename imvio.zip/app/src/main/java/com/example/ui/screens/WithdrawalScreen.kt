package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserEntity
import com.example.ui.components.GradientButton
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.LightBg
import com.example.ui.theme.LightCardBorder
import com.example.ui.theme.LightTextMuted
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary

@Composable
fun WithdrawalScreen(
    user: UserEntity?,
    onBackClick: () -> Unit,
    onSubmitWithdrawal: (points: Int, bkashNumber: String, onSuccess: (String) -> Unit, onError: (String) -> Unit) -> Unit,
    onNavigateToHistory: () -> Unit
) {
    var bkashNumber by remember(user?.bKashNumber) {
        mutableStateOf(user?.bKashNumber ?: "01712345678")
    }
    var pointsInput by remember { mutableStateOf("1000") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successRefId by remember { mutableStateOf<String?>(null) }

    val pointsInt = pointsInput.toIntOrNull() ?: 0
    val receiveBdt = pointsInt * 0.1

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LightBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("withdrawal_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("withdrawal_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = LightTextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Withdrawal",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = LightTextPrimary
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Available Balance Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFFEFF6FF))
                    .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Text(
                        text = "Available Balance",
                        color = Color(0xFF1E40AF),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "%,d Points".format(user?.pointsBalance ?: 2450),
                            color = Color(0xFF1E3A8A),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "≈ ৳%.2f".format((user?.pointsBalance ?: 2450) * 0.1),
                            color = Color(0xFF1D4ED8),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // bKash Number Input
            Text(
                text = "bKash Number",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = LightTextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = bkashNumber,
                onValueChange = { bkashNumber = it; errorMessage = null },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("withdrawal_bkash_input"),
                placeholder = { Text("01XXXXXXXXX", color = LightTextMuted) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandBlue,
                    unfocusedBorderColor = LightCardBorder,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Amount (Points) Input
            Text(
                text = "Amount (Points)",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = LightTextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = pointsInput,
                onValueChange = { pointsInput = it; errorMessage = null },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("withdrawal_points_input"),
                placeholder = { Text("1000", color = LightTextMuted) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandBlue,
                    unfocusedBorderColor = LightCardBorder,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Amount Selector Chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(1000, 2000, user?.pointsBalance ?: 2450).forEach { amt ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White)
                            .border(1.dp, LightCardBorder, RoundedCornerShape(10.dp))
                            .clickable { pointsInput = amt.toString() }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (amt == (user?.pointsBalance ?: 2450)) "All (${amt})" else "$amt Pts",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = BrandBlue
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Real-time calculation banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF0FDF4))
                    .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = BrandGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "You will receive: ৳%.2f".format(receiveBdt),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D)
                    )
                }
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = errorMessage!!,
                    color = Color(0xFFEF4444),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Submit Request Button
            GradientButton(
                text = "Submit Request",
                onClick = {
                    if (pointsInt < 1000) {
                        errorMessage = "Minimum withdrawal is 1,000 Points."
                    } else if (pointsInt > (user?.pointsBalance ?: 0)) {
                        errorMessage = "Insufficient points balance."
                    } else if (bkashNumber.length < 11 || !bkashNumber.startsWith("01")) {
                        errorMessage = "Please enter a valid 11-digit bKash number."
                    } else {
                        onSubmitWithdrawal(
                            pointsInt,
                            bkashNumber,
                            { ref -> successRefId = ref },
                            { err -> errorMessage = err }
                        )
                    }
                },
                testTag = "withdrawal_submit_btn"
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Withdrawal Rules Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(2.dp, RoundedCornerShape(18.dp), spotColor = Color(0x08000000))
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.White)
                    .border(1.dp, LightCardBorder, RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Text(
                        text = "Withdrawal Rules",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = LightTextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    WithdrawalRuleItem("Minimum 1,000 Points (৳100)")
                    Spacer(modifier = Modifier.height(6.dp))
                    WithdrawalRuleItem("Processing time: 1-3 business days")
                    Spacer(modifier = Modifier.height(6.dp))
                    WithdrawalRuleItem("Make sure your bKash personal number is active")
                    Spacer(modifier = Modifier.height(6.dp))
                    WithdrawalRuleItem("Points are held safely in escrow during review")
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }

    if (successRefId != null) {
        AlertDialog(
            onDismissRequest = {
                successRefId = null
                onNavigateToHistory()
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = BrandGreen,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = { Text("Request Submitted!") },
            text = {
                Column {
                    Text("Your withdrawal request has been placed successfully.")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Reference Code: $successRefId", fontWeight = FontWeight.Bold, color = BrandBlue)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("We will process ৳%.2f to $bkashNumber shortly.".format(receiveBdt))
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        successRefId = null
                        onNavigateToHistory()
                    }
                ) {
                    Text("View History")
                }
            }
        )
    }
}

@Composable
fun WithdrawalRuleItem(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(Color(0xFFDCFCE7)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = BrandGreen,
                modifier = Modifier.size(12.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            fontSize = 13.sp,
            color = LightTextSecondary
        )
    }
}
