package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GradientButton
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.DarkBg
import com.example.ui.theme.LightCardBorder
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary

data class PlanData(
    val name: String,
    val price: String,
    val isBestValue: Boolean = false,
    val features: List<String>
)

@Composable
fun SubscriptionPlansScreen(
    currentPlan: String,
    onBackClick: () -> Unit,
    onSelectPlan: (String) -> Unit
) {
    val plans = listOf(
        PlanData(
            name = "Starter",
            price = "৳999 / month",
            features = listOf(
                "Up to 10 Campaigns",
                "Basic Analytics",
                "Standard Support"
            )
        ),
        PlanData(
            name = "Pro",
            price = "৳2,499 / month",
            isBestValue = true,
            features = listOf(
                "Up to 50 Campaigns",
                "Advanced Analytics",
                "Priority Support"
            )
        ),
        PlanData(
            name = "Business",
            price = "৳4,999 / month",
            features = listOf(
                "Unlimited Campaigns",
                "Advanced Analytics",
                "Dedicated Support"
            )
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("subscription_plans_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("subscriptions_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Subscription Plans",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3 Subscription Plan Cards
            plans.forEach { plan ->
                val isSelected = plan.name.equals(currentPlan, ignoreCase = true)
                SubscriptionCard(
                    plan = plan,
                    isCurrent = isSelected,
                    onSelect = { onSelectPlan(plan.name) }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SubscriptionCard(
    plan: PlanData,
    isCurrent: Boolean,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(22.dp), spotColor = Color(0x20000000))
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .border(
                width = if (plan.isBestValue) 2.dp else 1.dp,
                color = if (plan.isBestValue) BrandBlue else LightCardBorder,
                shape = RoundedCornerShape(22.dp)
            )
            .padding(20.dp)
            .testTag("plan_card_${plan.name.lowercase()}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = plan.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = LightTextPrimary
                )

                if (plan.isBestValue) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(BrandBlue)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Best Value",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = plan.price,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (plan.isBestValue) BrandBlue else Color(0xFF1E293B)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Features list
            plan.features.forEach { feature ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 3.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = BrandGreen,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = feature,
                        fontSize = 13.sp,
                        color = LightTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Button: "Current Plan" or "Get Started"
            if (isCurrent) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .clip(RoundedCornerShape(23.dp))
                        .background(Color(0xFFF1F5F9)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Current Plan",
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            } else {
                GradientButton(
                    text = "Get Started",
                    onClick = onSelect,
                    modifier = Modifier.height(46.dp),
                    testTag = "btn_plan_${plan.name.lowercase()}"
                )
            }
        }
    }
}
