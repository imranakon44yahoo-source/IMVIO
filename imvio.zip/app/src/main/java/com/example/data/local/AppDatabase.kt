package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        TransactionEntity::class,
        CampaignEntity::class,
        TaskEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun transactionDao(): TransactionDao
    abstract fun campaignDao(): CampaignDao
    abstract fun taskDao(): TaskDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "imvio_database"
                )
                    .addCallback(AppDatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        suspend fun populateInitialData(db: AppDatabase) {
            // Seed user
            val userDao = db.userDao()
            val userId = userDao.insertUser(
                UserEntity(
                    id = 1,
                    name = "Imran Khan",
                    email = "imran@example.com",
                    password = "password123",
                    role = "VIEWER",
                    bKashNumber = "01712345678",
                    pointsBalance = 2450,
                    referralCode = "IMVIO-9821",
                    currentSubscription = "Pro"
                )
            )

            // Seed transactions
            val txDao = db.transactionDao()
            txDao.insertTransaction(
                TransactionEntity(
                    userId = userId,
                    type = "WITHDRAW",
                    title = "Withdrawal Request",
                    points = -1000,
                    bdtAmount = 100.0,
                    timestamp = System.currentTimeMillis() - 3600000 * 2,
                    dateDisplay = "18 Sep 2026, 10:30 AM",
                    status = "PENDING",
                    referenceId = "WDR-8932"
                )
            )
            txDao.insertTransaction(
                TransactionEntity(
                    userId = userId,
                    type = "EARN",
                    title = "Video Watch",
                    points = 50,
                    bdtAmount = 5.0,
                    timestamp = System.currentTimeMillis() - 3600000 * 5,
                    dateDisplay = "18 Sep 2026, 09:20 AM",
                    status = "COMPLETED"
                )
            )
            txDao.insertTransaction(
                TransactionEntity(
                    userId = userId,
                    type = "BONUS",
                    title = "Task Bonus",
                    points = 20,
                    bdtAmount = 2.0,
                    timestamp = System.currentTimeMillis() - 86400000,
                    dateDisplay = "17 Sep 2026, 06:15 PM",
                    status = "COMPLETED"
                )
            )
            txDao.insertTransaction(
                TransactionEntity(
                    userId = userId,
                    type = "WITHDRAW",
                    title = "Withdrawal",
                    points = -1000,
                    bdtAmount = 100.0,
                    timestamp = System.currentTimeMillis() - 86400000 * 3,
                    dateDisplay = "15 Sep 2026, 11:40 AM",
                    status = "COMPLETED",
                    referenceId = "WDR-7451"
                )
            )
            txDao.insertTransaction(
                TransactionEntity(
                    userId = userId,
                    type = "REFERRAL",
                    title = "Referral Bonus",
                    points = 100,
                    bdtAmount = 10.0,
                    timestamp = System.currentTimeMillis() - 86400000 * 4,
                    dateDisplay = "14 Sep 2026, 01:20 PM",
                    status = "COMPLETED"
                )
            )

            // Seed tasks
            val taskDao = db.taskDao()
            taskDao.insertAll(
                listOf(
                    TaskEntity(id = 1, title = "Watch Short Video", category = "WATCH", rewardPoints = 50, iconName = "play_circle", actionText = "Start"),
                    TaskEntity(id = 2, title = "Watch Full Video", category = "WATCH", rewardPoints = 100, iconName = "smart_display", actionText = "Start"),
                    TaskEntity(id = 3, title = "Like This Video", category = "TASK", rewardPoints = 20, iconName = "favorite", actionText = "Start"),
                    TaskEntity(id = 4, title = "Follow on YouTube", category = "TASK", rewardPoints = 50, iconName = "youtube", actionText = "Start"),
                    TaskEntity(id = 5, title = "Join Telegram", category = "TASK", rewardPoints = 30, iconName = "send", actionText = "Start"),
                    TaskEntity(id = 6, title = "Daily Check-in", category = "BONUS", rewardPoints = 10, iconName = "calendar_today", actionText = "Claim")
                )
            )

            // Seed campaigns
            val campaignDao = db.campaignDao()
            campaignDao.insertCampaign(
                CampaignEntity(
                    id = 1,
                    creatorId = userId,
                    title = "Travel Vlog Bangladesh",
                    platform = "YouTube",
                    videoUrl = "https://youtu.be/travel_bd",
                    viewsNeeded = 10000,
                    viewsCurrent = 8450,
                    budgetBdt = 800.0,
                    status = "ACTIVE"
                )
            )
            campaignDao.insertCampaign(
                CampaignEntity(
                    id = 2,
                    creatorId = userId,
                    title = "Healthy Lifestyle 101",
                    platform = "Facebook",
                    videoUrl = "https://fb.watch/healthy_tips",
                    viewsNeeded = 5000,
                    viewsCurrent = 4120,
                    budgetBdt = 450.0,
                    status = "ACTIVE"
                )
            )
            campaignDao.insertCampaign(
                CampaignEntity(
                    id = 3,
                    creatorId = userId,
                    title = "Dhaka Street Food Highlights",
                    platform = "TikTok",
                    videoUrl = "https://tiktok.com/@creator/food",
                    viewsNeeded = 15000,
                    viewsCurrent = 15000,
                    budgetBdt = 1200.0,
                    status = "COMPLETED"
                )
            )

            // Seed notifications
            val notifDao = db.notificationDao()
            notifDao.insertAll(
                listOf(
                    NotificationEntity(
                        userId = userId,
                        category = "PAYMENT",
                        title = "Your withdrawal request is approved",
                        body = "bKash payout of ৳100 has been sent to 01712345678 (TrxID: 9X87KL1P)",
                        timeAgo = "2 hours ago",
                        iconType = "check_circle",
                        targetScreen = "wallet"
                    ),
                    NotificationEntity(
                        userId = userId,
                        category = "SYSTEM",
                        title = "New video task available",
                        body = "Watch 'Travel Bangladesh' to earn +50 bonus points today!",
                        timeAgo = "5 hours ago",
                        iconType = "play_circle",
                        targetScreen = "video_watch"
                    ),
                    NotificationEntity(
                        userId = userId,
                        category = "CAMPAIGN",
                        title = "Your campaign is live",
                        body = "Campaign 'Travel Vlog Bangladesh' reached 8,000 views.",
                        timeAgo = "1 day ago",
                        iconType = "rocket_launch",
                        targetScreen = "creator_dashboard"
                    ),
                    NotificationEntity(
                        userId = userId,
                        category = "PAYMENT",
                        title = "You received 100 points",
                        body = "Referral bonus credited for inviting user @karim.",
                        timeAgo = "2 days ago",
                        iconType = "monetization_on",
                        targetScreen = "history"
                    ),
                    NotificationEntity(
                        userId = userId,
                        category = "SYSTEM",
                        title = "Subscription activated",
                        body = "Your Pro Creator monthly plan is active until 19 Oct 2026.",
                        timeAgo = "3 days ago",
                        iconType = "star",
                        targetScreen = "subscriptions"
                    ),
                    NotificationEntity(
                        userId = userId,
                        category = "SYSTEM",
                        title = "Welcome to iMVIO!",
                        body = "Create, Watch, and Earn rewards effortlessly.",
                        timeAgo = "3 days ago",
                        iconType = "celebration",
                        targetScreen = "viewer_home"
                    )
                )
            )
        }
    }
}
