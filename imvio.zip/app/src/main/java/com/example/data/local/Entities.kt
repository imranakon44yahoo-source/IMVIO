package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val email: String,
    val password: String = "password123",
    val role: String = "VIEWER", // VIEWER, CREATOR, ADMIN
    val bKashNumber: String = "01712345678",
    val pointsBalance: Int = 2450,
    val referralCode: String = "IMVIO-789",
    val currentSubscription: String = "Pro"
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long = 1,
    val type: String, // WITHDRAW, EARN, BONUS, REFERRAL, CONVERT
    val title: String,
    val points: Int, // e.g. -1000 or +50
    val bdtAmount: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val dateDisplay: String,
    val status: String = "COMPLETED", // PENDING, COMPLETED, REJECTED
    val referenceId: String = ""
)

@Entity(tableName = "campaigns")
data class CampaignEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val creatorId: Long = 1,
    val title: String,
    val platform: String = "YouTube",
    val videoUrl: String,
    val viewsNeeded: Int,
    val viewsCurrent: Int = 0,
    val budgetBdt: Double,
    val status: String = "ACTIVE", // ACTIVE, PENDING_REVIEW, PAUSED, COMPLETED, REJECTED
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String, // WATCH, TASK, BONUS
    val rewardPoints: Int,
    val iconName: String,
    val isCompleted: Boolean = false,
    val actionText: String = "Start"
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long = 1,
    val category: String, // SYSTEM, CAMPAIGN, PAYMENT
    val title: String,
    val body: String,
    val timeAgo: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val iconType: String = "system",
    val targetScreen: String = "notifications"
)
