package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.CampaignEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.TaskEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ImvioRepository(private val db: AppDatabase) {
    private val userDao = db.userDao()
    private val txDao = db.transactionDao()
    private val campaignDao = db.campaignDao()
    private val taskDao = db.taskDao()
    private val notifDao = db.notificationDao()

    val currentUser: Flow<UserEntity?> = userDao.getUserById(1)
    val allTransactions: Flow<List<TransactionEntity>> = txDao.getTransactionsByUserId(1)
    val allCampaigns: Flow<List<CampaignEntity>> = campaignDao.getAllCampaigns()
    val allTasks: Flow<List<TaskEntity>> = taskDao.getAllTasks()
    val allNotifications: Flow<List<NotificationEntity>> = notifDao.getNotifications(1)
    val allUsers: Flow<List<UserEntity>> = userDao.getAllUsers()
    val pendingWithdrawals: Flow<List<TransactionEntity>> = txDao.getPendingWithdrawals()

    suspend fun getUserSync(): UserEntity? {
        return currentUser.firstOrNull()
    }

    suspend fun signUp(name: String, email: String, password: String):Result<UserEntity> {
        val existing = userDao.getUserByEmail(email)
        if (existing != null) {
            return Result.failure(Exception("An account with this email already exists."))
        }
        val user = UserEntity(
            id = 1,
            name = name.ifBlank { "New Member" },
            email = email,
            password = password,
            role = "VIEWER",
            pointsBalance = 500, // Welcome signup bonus
            bKashNumber = "01XXXXXXXXX"
        )
        userDao.insertUser(user)

        // Add welcome bonus transaction
        val now = System.currentTimeMillis()
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(now))
        txDao.insertTransaction(
            TransactionEntity(
                userId = 1,
                type = "BONUS",
                title = "Sign Up Welcome Bonus",
                points = 500,
                bdtAmount = 50.0,
                timestamp = now,
                dateDisplay = dateStr,
                status = "COMPLETED"
            )
        )
        return Result.success(user)
    }

    suspend fun login(email: String, password: String): Result<UserEntity> {
        val user = userDao.getUserByEmail(email) ?: getUserSync()
        return if (user != null) {
            Result.success(user)
        } else {
            // Create demo session if first launch
            val newUser = UserEntity(
                id = 1,
                name = email.substringBefore("@").replaceFirstChar { it.uppercase() },
                email = email,
                password = password,
                role = "VIEWER",
                pointsBalance = 2450
            )
            userDao.insertUser(newUser)
            Result.success(newUser)
        }
    }

    suspend fun updateRole(role: String) {
        userDao.updateRole(1, role)
    }

    suspend fun updateBkash(number: String) {
        userDao.updateBkash(1, number)
    }

    suspend fun updateProfile(name: String, email: String) {
        val current = getUserSync() ?: return
        userDao.updateUser(current.copy(name = name, email = email))
    }

    suspend fun awardVideoWatchReward(points: Int, videoTitle: String): Boolean {
        val current = getUserSync() ?: return false
        userDao.updatePoints(current.id, points)

        val now = System.currentTimeMillis()
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(now))
        txDao.insertTransaction(
            TransactionEntity(
                userId = current.id,
                type = "EARN",
                title = "Video Watch: $videoTitle",
                points = points,
                bdtAmount = points * 0.1,
                timestamp = now,
                dateDisplay = dateStr,
                status = "COMPLETED"
            )
        )

        notifDao.insertNotification(
            NotificationEntity(
                userId = current.id,
                category = "PAYMENT",
                title = "Reward Earned!",
                body = "You earned +$points points for watching '$videoTitle'.",
                timeAgo = "Just now",
                iconType = "monetization_on",
                targetScreen = "wallet"
            )
        )
        return true
    }

    suspend fun completeTask(taskId: Long, rewardPoints: Int, taskTitle: String): Boolean {
        val current = getUserSync() ?: return false
        taskDao.markCompleted(taskId)
        userDao.updatePoints(current.id, rewardPoints)

        val now = System.currentTimeMillis()
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(now))
        txDao.insertTransaction(
            TransactionEntity(
                userId = current.id,
                type = "TASK",
                title = taskTitle,
                points = rewardPoints,
                bdtAmount = rewardPoints * 0.1,
                timestamp = now,
                dateDisplay = dateStr,
                status = "COMPLETED"
            )
        )

        notifDao.insertNotification(
            NotificationEntity(
                userId = current.id,
                category = "PAYMENT",
                title = "Task Completed!",
                body = "Received +$rewardPoints points for completing '$taskTitle'.",
                timeAgo = "Just now",
                iconType = "check_circle",
                targetScreen = "wallet"
            )
        )
        return true
    }

    suspend fun requestWithdrawal(points: Int, bkashNumber: String): Result<String> {
        val current = getUserSync() ?: return Result.failure(Exception("User not found"))
        if (points < 1000) {
            return Result.failure(Exception("Minimum withdrawal is 1,000 Points."))
        }
        if (points > current.pointsBalance) {
            return Result.failure(Exception("Insufficient balance. You have ${current.pointsBalance} points."))
        }
        if (bkashNumber.length < 11 || !bkashNumber.startsWith("01")) {
            return Result.failure(Exception("Please enter a valid 11-digit bKash number starting with 01."))
        }

        // Atomically reserve points
        userDao.updatePoints(current.id, -points)
        userDao.updateBkash(current.id, bkashNumber)

        val refId = "WDR-" + UUID.randomUUID().toString().take(6).uppercase()
        val now = System.currentTimeMillis()
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(now))
        val bdtValue = points * 0.1

        txDao.insertTransaction(
            TransactionEntity(
                userId = current.id,
                type = "WITHDRAW",
                title = "Withdrawal Request",
                points = -points,
                bdtAmount = bdtValue,
                timestamp = now,
                dateDisplay = dateStr,
                status = "PENDING",
                referenceId = refId
            )
        )

        notifDao.insertNotification(
            NotificationEntity(
                userId = current.id,
                category = "PAYMENT",
                title = "Withdrawal Submitted",
                body = "Request for ৳${bdtValue.toInt()} (Ref: $refId) to $bkashNumber is pending review.",
                timeAgo = "Just now",
                iconType = "account_balance_wallet",
                targetScreen = "history"
            )
        )
        return Result.success(refId)
    }

    suspend fun createCampaign(
        title: String,
        platform: String,
        videoUrl: String,
        viewsNeeded: Int,
        budgetBdt: Double
    ): Long {
        val campaign = CampaignEntity(
            creatorId = 1,
            title = title,
            platform = platform,
            videoUrl = videoUrl,
            viewsNeeded = viewsNeeded,
            viewsCurrent = 0,
            budgetBdt = budgetBdt,
            status = "ACTIVE"
        )
        val id = campaignDao.insertCampaign(campaign)

        notifDao.insertNotification(
            NotificationEntity(
                userId = 1,
                category = "CAMPAIGN",
                title = "Campaign Created!",
                body = "Campaign '$title' is now active for $viewsNeeded views.",
                timeAgo = "Just now",
                iconType = "rocket_launch",
                targetScreen = "creator_dashboard"
            )
        )
        return id
    }

    suspend fun selectSubscription(planName: String) {
        userDao.updateSubscription(1, planName)
        notifDao.insertNotification(
            NotificationEntity(
                userId = 1,
                category = "SYSTEM",
                title = "Subscription Updated",
                body = "You are now on the $planName plan.",
                timeAgo = "Just now",
                iconType = "star",
                targetScreen = "subscriptions"
            )
        )
    }

    suspend fun adminApproveWithdrawal(txId: Long, payoutTrxId: String) {
        txDao.updateStatus(txId, "COMPLETED")
    }

    suspend fun adminRejectWithdrawal(txId: Long, refundPoints: Int) {
        txDao.updateStatus(txId, "REJECTED")
        // Refund points atomically
        userDao.updatePoints(1, kotlin.math.abs(refundPoints))

        val now = System.currentTimeMillis()
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(now))
        txDao.insertTransaction(
            TransactionEntity(
                userId = 1,
                type = "BONUS",
                title = "Withdrawal Refund",
                points = kotlin.math.abs(refundPoints),
                bdtAmount = kotlin.math.abs(refundPoints) * 0.1,
                timestamp = now,
                dateDisplay = dateStr,
                status = "COMPLETED"
            )
        )
    }

    suspend fun adminUpdateCampaignStatus(campaignId: Long, status: String) {
        campaignDao.updateCampaignStatus(campaignId, status)
    }

    suspend fun markNotificationAsRead(id: Long) {
        notifDao.markAsRead(id)
    }

    suspend fun markAllNotificationsAsRead() {
        notifDao.markAllAsRead(1)
    }
}
